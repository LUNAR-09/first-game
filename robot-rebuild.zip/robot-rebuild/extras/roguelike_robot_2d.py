# -*- coding: utf-8 -*-
"""
폐허의 도시 : 리빌드  (Ruined City : Rebuild)
망가진 로봇이 적을 쓰러뜨릴수록 몸이 수리되어 세계 최강의 로봇이 되는 로그라이크 액션

[조작]
  ← → / A D : 이동          Space / ↑ / W : 점프 (증강으로 2단 점프 가능)
  사격은 가장 가까운 적을 향해 자동 조준 + 자동 발사
  P / ESC : 일시정지        1 2 3 : 증강 선택 (마우스 클릭도 가능)
  메뉴: ↑ ↓ 로 난이도 선택, Enter 로 시작
"""
import pygame
import random
import math
import sys
import os
import json

pygame.init()

# ------------------------------------------------------------
# 기본 설정
# ------------------------------------------------------------
WORLD_W, WORLD_H = 900, 540          # 게임 보드 크기
PANEL_W = 200                        # 왼쪽 리더보드 너비
WIN_W, WIN_H = WORLD_W + PANEL_W, WORLD_H
GROUND_Y = 480                       # 바닥 윗면 높이
GRAV = 0.6
JUMP_V = 13.0
STAGE_TIME = 120.0                   # 2분마다 보스 + 스테이지 상승
FPS = 60

screen = pygame.display.set_mode((WIN_W, WIN_H))
pygame.display.set_caption("Ruined City : Rebuild")
clock = pygame.time.Clock()


# ------------------------------------------------------------
# 폰트 (한글 폰트가 있으면 한글, 없으면 영어로 표시)
# ------------------------------------------------------------
def find_korean_font():
    names = ("malgungothic", "malgun gothic", "applegothic", "applesdgothicneo",
             "nanumgothic", "nanumbarungothic", "notosanscjkkr", "notosanskr",
             "gulim", "dotum", "batang")
    for n in names:
        try:
            p = pygame.font.match_font(n)
        except Exception:
            p = None
        if p:
            return p
    return None


KFONT = find_korean_font()
KO = KFONT is not None


def make_font(size):
    if KFONT:
        return pygame.font.Font(KFONT, size)
    return pygame.font.SysFont(None, int(size * 1.15))


F_S = make_font(15)
F_M = make_font(20)
F_L = make_font(34)
F_XL = make_font(58)


def T(ko, en):
    return ko if KO else en


# ------------------------------------------------------------
# 난이도
# ------------------------------------------------------------
DIFFS = [
    dict(key="rookie", ko="초보", en="ROOKIE", sko="초보", sen="ROK",
         hp=0.75, dmg=0.7, spawn=1.35, php=140, mult=1.0, color=(110, 230, 130)),
    dict(key="veteran", ko="베테랑", en="VETERAN", sko="베테랑", sen="VET",
         hp=1.0, dmg=1.0, spawn=1.0, php=115, mult=1.5, color=(240, 220, 90)),
    dict(key="insane", ko="인세인", en="INSANE", sko="인세인", sen="INS",
         hp=1.45, dmg=1.4, spawn=0.72, php=100, mult=2.5, color=(255, 140, 50)),
    dict(key="nightmare", ko="나이트메어", en="NIGHTMARE", sko="나이트", sen="NTM",
         hp=2.0, dmg=2.0, spawn=0.5, php=90, mult=4.0, color=(255, 60, 80)),
]


def dname(d):
    return d["ko"] if KO else d["en"]


def dshort(d):
    return d["sko"] if KO else d["sen"]


def diff_by_key(k):
    for d in DIFFS:
        if d["key"] == k:
            return d
    return DIFFS[1]


# ------------------------------------------------------------
# 기록(리더보드) 저장
# ------------------------------------------------------------
try:
    _BASE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _BASE = os.getcwd()
SAVE_PATH = os.path.join(_BASE, "robot_records.json")


def load_records():
    try:
        with open(SAVE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        recs = [r for r in data if isinstance(r, dict) and "score" in r]
        recs.sort(key=lambda r: -r["score"])
        return recs[:10]
    except Exception:
        return []


def save_records(recs):
    try:
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            json.dump(recs, f, ensure_ascii=False)
    except Exception:
        pass


def add_record(recs, game):
    rec = dict(score=int(game.score), stage=game.stage, kills=game.p.kills,
               diff=game.d["key"], level=game.p.level)
    recs.append(rec)
    recs.sort(key=lambda r: -r["score"])
    del recs[10:]
    save_records(recs)
    game.saved = True
    return recs.index(rec) + 1 if rec in recs else None


# ------------------------------------------------------------
# 유틸
# ------------------------------------------------------------
def clamp(v, a, b):
    return max(a, min(b, v))


def draw_text(surf, text, font, color, pos, anchor="topleft", shadow=True):
    img = font.render(str(text), True, color)
    r = img.get_rect(**{anchor: pos})
    if shadow:
        sh = font.render(str(text), True, (0, 0, 0))
        surf.blit(sh, (r.x + 1, r.y + 1))
    surf.blit(img, r)
    return r


def lerp_color(c1, c2, k):
    return (int(c1[0] + (c2[0] - c1[0]) * k),
            int(c1[1] + (c2[1] - c1[1]) * k),
            int(c1[2] + (c2[2] - c1[2]) * k))


# 바닥 + 떠 있는 발판
GROUND = pygame.Rect(0, GROUND_Y, WORLD_W, WORLD_H - GROUND_Y)
FLOATING = [pygame.Rect(120, 370, 170, 14),
            pygame.Rect(610, 370, 170, 14),
            pygame.Rect(365, 270, 170, 14)]
SURFACES = [GROUND] + FLOATING


def move_entity(e, dx, f):
    """좌우 이동 + 중력 + 발판(위에서만 착지) 충돌"""
    e.x = clamp(e.x + dx, 0, WORLD_W - e.w)
    prev_bottom = e.y + e.h
    e.vy = min(e.vy + GRAV * f, 16.0)
    e.y += e.vy * f
    e.on_ground = False
    if e.vy >= 0:
        for s in SURFACES:
            if (e.x + e.w > s.left and e.x < s.right and
                    prev_bottom <= s.top + 3 and e.y + e.h >= s.top):
                e.y = s.top - e.h
                e.vy = 0.0
                e.on_ground = True
                break


# ------------------------------------------------------------
# 배경 (폐허가 된 도시)
# ------------------------------------------------------------
def make_background():
    rnd = random.Random(11)
    s = pygame.Surface((WORLD_W, WORLD_H))
    for y in range(WORLD_H):
        k = y / WORLD_H
        pygame.draw.line(s, (int(28 + 100 * k), int(20 + 52 * k), int(40 + 8 * k)),
                         (0, y), (WORLD_W, y))
    pygame.draw.circle(s, (150, 80, 62), (690, 300), 62)
    pygame.draw.circle(s, (180, 100, 70), (690, 300), 40)
    layers = [((52, 36, 54), 120, 300, 50, 100), ((30, 23, 38), 70, 230, 40, 90)]
    for li, (col, hmin, hmax, wmin, wmax) in enumerate(layers):
        x = -20
        while x < WORLD_W:
            bw = rnd.randint(wmin, wmax)
            bh = rnd.randint(hmin, hmax)
            top = GROUND_Y - bh
            pts = [(x, GROUND_Y), (x, top)]
            seg = rnd.randint(2, 4)
            for i in range(1, seg + 1):
                pts.append((x + bw * i // seg, top + rnd.randint(-6, 38)))
            pts.append((x + bw, GROUND_Y))
            pygame.draw.polygon(s, col, pts)
            if li == 1:
                for _ in range(rnd.randint(2, 6)):
                    wx = x + rnd.randint(4, max(5, bw - 10))
                    wy = top + rnd.randint(40, max(41, bh - 10))
                    pygame.draw.rect(s, (210, 150, 70) if rnd.random() < 0.3 else (60, 45, 55),
                                     (wx, wy, 5, 7))
            x += bw + rnd.randint(-8, 14)
    # 철골 잔해
    for _ in range(14):
        bx = rnd.randint(0, WORLD_W)
        pygame.draw.line(s, (20, 16, 24), (bx, GROUND_Y), (bx + rnd.randint(-30, 30), GROUND_Y - rnd.randint(20, 60)), 3)
    return s


BG = make_background()


# ------------------------------------------------------------
# 이펙트
# ------------------------------------------------------------
class Spark:
    def __init__(self, x, y, vx, vy, life, color, size=3, grav=0.25, debris=False):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max_life = life
        self.color, self.size, self.grav, self.debris = color, size, grav, debris

    def update(self, f, dt):
        self.x += self.vx * f
        self.y += self.vy * f
        self.vy += self.grav * f
        self.life -= dt

    def draw(self, surf):
        k = max(0.0, self.life / self.max_life)
        sz = max(1, int(self.size * (0.4 + 0.6 * k)))
        col = lerp_color((20, 10, 10), self.color, k)
        if self.debris:
            pygame.draw.rect(surf, col, (int(self.x), int(self.y), sz, sz))
        else:
            pygame.draw.circle(surf, col, (int(self.x), int(self.y)), sz)


class Ring:
    def __init__(self, x, y, r0, r1, life, color, width=3):
        self.x, self.y, self.r0, self.r1 = x, y, r0, r1
        self.life = self.max_life = life
        self.color, self.width = color, width

    def update(self, f, dt):
        self.life -= dt

    def draw(self, surf):
        k = clamp(self.life / self.max_life, 0.0, 1.0)
        r = int(self.r1 + (self.r0 - self.r1) * k)
        col = lerp_color((0, 0, 0), self.color, k)
        w = self.width if self.width > 0 else 0
        pygame.draw.circle(surf, col, (int(self.x), int(self.y)), max(1, r), w)


class FloatText:
    def __init__(self, x, y, text, color, big=False, life=1.0):
        self.x, self.y, self.text, self.color, self.big = x, y, text, color, big
        self.life = self.max_life = life

    def update(self, f, dt):
        self.y -= 0.7 * f
        self.life -= dt

    def draw(self, surf):
        draw_text(surf, self.text, F_M if self.big else F_S, self.color,
                  (int(self.x), int(self.y)), "center")


# ------------------------------------------------------------
# 총알
# ------------------------------------------------------------
class Bullet:
    def __init__(self, x, y, vx, vy, dmg, friendly, r=4, color=(255, 255, 255),
                 pierce=0, explosive=0, homing=False, life=2.5, crit=False):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.dmg, self.friendly, self.r, self.color = dmg, friendly, r, color
        self.pierce, self.explosive, self.homing = pierce, explosive, homing
        self.life, self.crit = life, crit
        self.speed = math.hypot(vx, vy)
        self.hit = set()
        self.dead = False

    def update(self, g, dt, f):
        if self.homing:
            target = g.nearest_enemy(self.x, self.y, 9999, need_visible=True)
            if target:
                tx, ty = target.x + target.w / 2, target.y + target.h / 2
                desired = math.atan2(ty - self.y, tx - self.x)
                cur = math.atan2(self.vy, self.vx)
                diff = (desired - cur + math.pi) % (2 * math.pi) - math.pi
                cur += clamp(diff, -0.12 * f, 0.12 * f)
                self.vx = math.cos(cur) * self.speed
                self.vy = math.sin(cur) * self.speed
        self.x += self.vx * f
        self.y += self.vy * f
        self.life -= dt
        if (self.life <= 0 or self.x < -30 or self.x > WORLD_W + 30 or
                self.y < -40 or self.y > GROUND_Y + 6):
            self.dead = True

    def draw(self, surf):
        c = self.color
        pygame.draw.circle(surf, lerp_color((0, 0, 0), c, 0.45), (int(self.x), int(self.y)), self.r + 2)
        pygame.draw.circle(surf, c, (int(self.x), int(self.y)), self.r)
        if not self.friendly:
            pygame.draw.circle(surf, (255, 240, 220), (int(self.x), int(self.y)), max(1, self.r - 3))


# ------------------------------------------------------------
# 플레이어
# ------------------------------------------------------------
REPAIR_AT = [6, 20, 42, 75, 120]     # 처치 수에 따라 수리되는 부위
REPAIR_NAMES = [("다리", "LEGS"), ("사격팔", "GUN ARM"), ("왼팔", "LEFT ARM"),
                ("머리", "HEAD"), ("코어", "CORE")]


class Player:
    def __init__(self, diff):
        self.w, self.h = 34, 48
        self.x = WORLD_W / 2 - self.w / 2
        self.y = GROUND_Y - self.h
        self.vx = self.vy = 0.0
        self.kb = 0.0
        self.on_ground = True
        self.moving = False
        self.facing = 1
        self.max_hp = float(diff["php"])
        self.hp = self.max_hp
        self.dmg = 10.0
        self.fire_delay = 0.34
        self.fire_cd = 0.0
        self.speed = 4.0
        self.extra_jumps = 0
        self.air_left = 0
        self.bullets = 1
        self.pierce = 0
        self.explosive = 0
        self.lifesteal = 0.0
        self.regen = 0.0
        self.crit = 0.05
        self.shield_lvl = 0
        self.shield_ready = False
        self.shield_cd = 0.0
        self.missile = 0
        self.missile_cd = 2.0
        self.saw = 0
        self.saw_angle = 0.0
        self.inv = 0.0
        self.xp = 0
        self.level = 1
        self.kills = 0
        self.repair = 0
        self.aug = {}

    @property
    def cx(self):
        return self.x + self.w / 2

    @property
    def cy(self):
        return self.y + self.h / 2

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def xp_need(self):
        return 25 + 15 * (self.level - 1)


# ------------------------------------------------------------
# 증강 (로그라이크 요소)
# ------------------------------------------------------------
def a_hp(p):
    p.max_hp += 30
    p.hp = min(p.max_hp, p.hp + 30)


def a_dmg(p):
    p.dmg *= 1.25


def a_rate(p):
    p.fire_delay = max(0.08, p.fire_delay * 0.83)


def a_speed(p):
    p.speed *= 1.12


def a_jump(p):
    p.extra_jumps += 1


def a_multi(p):
    p.bullets += 1


def a_pierce(p):
    p.pierce += 1


def a_explosive(p):
    p.explosive += 1


def a_lifesteal(p):
    p.lifesteal += 2.0


def a_regen(p):
    p.regen += 1.0


def a_shield(p):
    p.shield_lvl += 1
    p.shield_ready = True


def a_missile(p):
    p.missile += 1


def a_saw(p):
    p.saw += 1


def a_crit(p):
    p.crit += 0.15


def a_heal(p):
    p.hp = min(p.max_hp, p.hp + p.max_hp * 0.5)


AUGS = [
    dict(key="hp", ko=("강화 장갑", "최대 HP +30, 즉시 30 회복"), en=("Reinforced Armor", "Max HP +30 and heal 30"), max=99, fn=a_hp, color=(110, 220, 120)),
    dict(key="dmg", ko=("고출력 탄", "공격력 +25%"), en=("Overcharged Rounds", "Damage +25%"), max=8, fn=a_dmg, color=(255, 110, 90)),
    dict(key="rate", ko=("고속 장전", "발사 속도 +20%"), en=("Rapid Loader", "Fire rate +20%"), max=6, fn=a_rate, color=(255, 200, 80)),
    dict(key="speed", ko=("추진 부스터", "이동 속도 +12%"), en=("Thruster Boost", "Move speed +12%"), max=4, fn=a_speed, color=(120, 200, 255)),
    dict(key="jump", ko=("공중 점프", "공중에서 점프 +1회"), en=("Air Jump", "+1 mid-air jump"), max=2, fn=a_jump, color=(170, 160, 255)),
    dict(key="multi", ko=("다중 발사", "한 번에 쏘는 탄 +1"), en=("Multi-Shot", "+1 projectile per shot"), max=4, fn=a_multi, color=(120, 230, 255)),
    dict(key="pierce", ko=("관통탄", "탄이 적을 +1 관통"), en=("Piercing Rounds", "Bullets pierce +1 enemy"), max=3, fn=a_pierce, color=(200, 200, 255)),
    dict(key="explosive", ko=("폭발탄", "착탄 시 주변 폭발"), en=("Explosive Rounds", "Bullets explode on hit"), max=3, fn=a_explosive, color=(255, 150, 60)),
    dict(key="lifesteal", ko=("나노 수리", "적 처치 시 HP +2"), en=("Nano Repair", "Heal 2 HP per kill"), max=5, fn=a_lifesteal, color=(110, 255, 160)),
    dict(key="regen", ko=("자가 수복", "초당 HP +1 회복"), en=("Auto-Repair", "Regenerate 1 HP/sec"), max=4, fn=a_regen, color=(90, 230, 190)),
    dict(key="shield", ko=("에너지 실드", "피해 1회 막기 (재충전)"), en=("Energy Shield", "Block 1 hit (recharges)"), max=3, fn=a_shield, color=(100, 200, 255)),
    dict(key="missile", ko=("추적 미사일", "주기적으로 유도 미사일 발사"), en=("Homing Missiles", "Auto-fires homing missiles"), max=4, fn=a_missile, color=(255, 120, 80)),
    dict(key="saw", ko=("회전 톱날", "몸 주위를 도는 톱날 +1"), en=("Orbital Saw", "+1 orbiting saw blade"), max=4, fn=a_saw, color=(210, 210, 220)),
    dict(key="crit", ko=("치명 코어", "치명타 확률 +15% (2배 피해)"), en=("Critical Core", "+15% crit chance (x2 dmg)"), max=4, fn=a_crit, color=(255, 230, 90)),
    dict(key="heal", ko=("긴급 수리 키트", "HP 50% 즉시 회복"), en=("Emergency Kit", "Heal 50% HP now"), max=999, fn=a_heal, color=(255, 120, 160)),
]


def aug_name(a):
    return a["ko"][0] if KO else a["en"][0]


def aug_desc(a):
    return a["ko"][1] if KO else a["en"][1]


# ------------------------------------------------------------
# 일반 적
# ------------------------------------------------------------
ETYPES = {
    "scrap": dict(w=30, h=34, hp=22, speed=1.5, dmg=10, score=10, xp=6, kind="ground"),
    "kami": dict(w=26, h=26, hp=14, speed=3.3, dmg=22, score=15, xp=8, kind="ground"),
    "drone": dict(w=30, h=22, hp=16, speed=1.7, dmg=8, score=14, xp=7, kind="fly", shoot=2.8),
    "gunner": dict(w=30, h=36, hp=34, speed=0.7, dmg=8, score=22, xp=12, kind="platform", shoot=1.8),
    "tank": dict(w=54, h=40, hp=100, speed=0.7, dmg=18, score=45, xp=25, kind="ground", shoot=3.2),
}


class Enemy:
    is_boss = False

    def __init__(self, g, t, x, y, plat=None):
        cfg = ETYPES[t]
        self.t = t
        self.kind = cfg["kind"]
        self.w, self.h = cfg["w"], cfg["h"]
        st = g.stage - 1
        self.max_hp = cfg["hp"] * g.d["hp"] * (1 + 0.22 * st)
        self.hp = self.max_hp
        self.speed = min(cfg["speed"] * (1 + 0.04 * st), cfg["speed"] * 1.6) * random.uniform(0.92, 1.08)
        self.dmg = cfg["dmg"] * g.d["dmg"] * (1 + 0.08 * st)
        self.score = cfg["score"]
        self.xp = int(cfg["xp"] * (1 + 0.1 * st))
        self.shoot = cfg.get("shoot", 0)
        self.cd = random.uniform(0.6, self.shoot) if self.shoot else 0
        self.x, self.y = float(x), float(y)
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.dir = 1
        self.aim = 0.0
        self.flash = 0.0
        self.grace = 0.7
        self.saw_cd = 0.0
        self.dead = False
        self.phase = random.random() * 6.28
        self.age = 0.0
        self.plat = plat

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def update(self, g, dt, f):
        self.age += dt
        self.grace = max(0.0, self.grace - dt)
        self.flash = max(0.0, self.flash - dt)
        self.saw_cd -= dt
        p = g.p
        cx, cy = self.x + self.w / 2, self.y + self.h / 2
        if self.kind == "ground":
            self.dir = 1 if p.cx > cx else -1
            move_entity(self, self.dir * self.speed * f, f)
            if self.t == "tank":
                self.cd -= dt
                if self.cd <= 0 and self.grace <= 0:
                    self.cd = self.shoot * random.uniform(0.9, 1.2)
                    ang = 0 if self.dir > 0 else math.pi
                    g.enemy_shot(cx + self.dir * 28, self.y + 12, ang, 5.0, self.dmg * 0.6, 6)
        elif self.kind == "fly":
            dx = p.cx - cx
            ty = 100 + 55 * math.sin(self.age * 1.6 + self.phase)
            self.x = clamp(self.x + clamp(dx * 0.02, -self.speed, self.speed) * f, 0, WORLD_W - self.w)
            self.y += clamp((ty - cy) * 0.04, -2.0, 2.0) * f
            self.dir = 1 if dx > 0 else -1
            self.cd -= dt
            if self.cd <= 0 and self.grace <= 0:
                self.cd = self.shoot * random.uniform(0.8, 1.2)
                ang = math.atan2(p.cy - cy, p.cx - cx)
                g.enemy_shot(cx, cy + 6, ang, 4.2, self.dmg * 0.8, 5)
        else:  # platform (gunner)
            self.x += self.dir * self.speed * f
            if self.x < self.plat.left:
                self.x = self.plat.left
                self.dir = 1
            if self.x + self.w > self.plat.right:
                self.x = self.plat.right - self.w
                self.dir = -1
            self.aim = math.atan2(p.cy - (self.y + 14), p.cx - cx)
            self.cd -= dt
            if self.cd <= 0 and self.grace <= 0:
                self.cd = self.shoot * random.uniform(0.85, 1.15)
                g.enemy_shot(cx + math.cos(self.aim) * 18, self.y + 14 + math.sin(self.aim) * 18,
                             self.aim, 4.6, self.dmg, 5)

    def draw(self, surf, t):
        x, y, w, h = int(self.x), int(self.y), self.w, self.h
        if self.grace > 0:
            if int(t * 18) % 2 == 0:
                pygame.draw.ellipse(surf, (120, 200, 255), (x - 4, y + h - 6, w + 8, 10), 2)
            return
        fl = self.flash > 0

        def c(col):
            return (255, 255, 255) if fl else col

        cx = x + w // 2
        if self.t == "scrap":
            sw = int(math.sin(self.age * 10 + self.phase) * 3)
            pygame.draw.rect(surf, c((90, 60, 40)), (x + 4 + sw, y + h - 12, 8, 12))
            pygame.draw.rect(surf, c((90, 60, 40)), (x + w - 12 - sw, y + h - 12, 8, 12))
            pygame.draw.rect(surf, c((150, 100, 60)), (x, y + 8, w, h - 18), border_radius=3)
            pygame.draw.rect(surf, c((120, 120, 130)), (x + 4, y, w - 8, 10))
            pygame.draw.circle(surf, c((255, 60, 40)), (cx + self.dir * 5, y + 5), 3)
            pygame.draw.line(surf, (70, 45, 30), (x + 5, y + 14), (x + 12, y + 22), 2)
            pygame.draw.rect(surf, c((110, 110, 130)), (x + (w - 4 if self.dir > 0 else -4), y + 14, 8, 5))
        elif self.t == "kami":
            pygame.draw.circle(surf, c((200, 50, 50)), (cx, y + 13), 13)
            for k in range(8):
                a = k * math.pi / 4 + self.age * 3
                pygame.draw.line(surf, c((255, 120, 80)), (cx, y + 13),
                                 (cx + math.cos(a) * 17, y + 13 + math.sin(a) * 17), 3)
            pygame.draw.circle(surf, c((255, 255, 120) if int(self.age * 8) % 2 else (120, 20, 20)), (cx, y + 13), 5)
        elif self.t == "drone":
            pygame.draw.ellipse(surf, c((90, 140, 190)), (x, y + 4, w, h - 4))
            pygame.draw.circle(surf, c((255, 70, 60)), (cx, y + 12), 4)
            rx = math.cos(self.age * 30) * 17
            pygame.draw.line(surf, c((200, 210, 220)), (cx - rx, y + 2), (cx + rx, y + 2), 3)
            pygame.draw.line(surf, c((60, 80, 100)), (cx, y + 2), (cx, y + 6), 2)
        elif self.t == "gunner":
            pygame.draw.rect(surf, c((70, 70, 90)), (x + 5, y + h - 12, 7, 12))
            pygame.draw.rect(surf, c((70, 70, 90)), (x + w - 12, y + h - 12, 7, 12))
            pygame.draw.rect(surf, c((120, 120, 150)), (x + 2, y + 10, w - 4, h - 20), border_radius=3)
            pygame.draw.rect(surf, c((150, 150, 175)), (x + 6, y, w - 12, 12), border_radius=3)
            pygame.draw.circle(surf, c((255, 80, 60)), (cx, y + 6), 3)
            bx, by = cx + math.cos(self.aim) * 20, y + 14 + math.sin(self.aim) * 20
            pygame.draw.line(surf, c((40, 40, 55)), (cx, y + 14), (bx, by), 5)
        elif self.t == "tank":
            pygame.draw.rect(surf, c((45, 50, 45)), (x, y + h - 14, w, 14), border_radius=6)
            for k in range(4):
                pygame.draw.circle(surf, c((90, 95, 90)), (x + 8 + k * 13, y + h - 7), 5)
            pygame.draw.rect(surf, c((90, 115, 80)), (x + 4, y + 8, w - 8, h - 20), border_radius=4)
            pygame.draw.circle(surf, c((110, 135, 100)), (cx, y + 10), 10)
            pygame.draw.line(surf, c((40, 50, 40)), (cx, y + 10), (cx + self.dir * 28, y + 10), 6)
        if self.hp < self.max_hp:
            pygame.draw.rect(surf, (40, 0, 0), (x, y - 8, w, 4))
            pygame.draw.rect(surf, (230, 60, 50), (x, y - 8, int(w * max(0, self.hp) / self.max_hp), 4))


# ------------------------------------------------------------
# 보스
# ------------------------------------------------------------
class Boss:
    is_boss = True
    NAMES = [("강철 골리앗", "IRON GOLIATH"), ("하늘의 사신", "SKY REAPER"), ("오메가 코어", "OMEGA CORE")]
    SIZES = [(92, 104), (110, 56), (84, 84)]

    def __init__(self, g, n):
        self.n = n
        self.idx = n % 3
        self.t = "boss"
        self.w, self.h = self.SIZES[self.idx]
        self.kind = "fly" if self.idx == 1 else "ground"
        self.max_hp = 450 * (1 + 0.55 * n) * g.d["hp"]
        self.hp = self.max_hp
        self.dmg = 22 * g.d["dmg"] * (1 + 0.08 * n)
        self.score = 300 * (n + 1)
        self.xp = 90
        self.x = float(random.choice([20, WORLD_W - self.w - 20]))
        self.y = float(-self.h - 10)
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.dir = 1
        self.flash = 0.0
        self.grace = 1.4
        self.saw_cd = 0.0
        self.dead = False
        self.age = 0.0
        self.cd1, self.cd2, self.cd3 = 2.0, 4.5, 6.0
        self.leaping = False
        self.leap_dir = 1
        self.leap_t = 0.0
        self.ang0 = 0.0

    @property
    def name(self):
        return self.NAMES[self.idx][0] if KO else self.NAMES[self.idx][1]

    @property
    def enraged(self):
        return self.hp < self.max_hp * 0.5

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def update(self, g, dt, f):
        self.age += dt
        self.grace = max(0.0, self.grace - dt)
        self.flash = max(0.0, self.flash - dt)
        self.saw_cd -= dt
        p = g.p
        cx, cy = self.x + self.w / 2, self.y + self.h / 2
        rage = 0.65 if self.enraged else 1.0
        spd = 1.4 if self.enraged else 1.0
        dx = p.cx - cx
        self.dir = 1 if dx > 0 else -1
        active = self.grace <= 0
        if self.idx == 0:       # 강철 골리앗: 추격 + 3연 사격 + 도약
            if self.leaping:
                self.leap_t += dt
                move_entity(self, self.leap_dir * 3.8 * f, f)
                if self.on_ground and self.leap_t > 0.25:
                    self.leaping = False
                    g.rings.append(Ring(cx, self.y + self.h, 10, 90, 0.4, (255, 200, 120), 4))
                    g.shake = max(g.shake, 0.25)
            else:
                move_entity(self, self.dir * 1.0 * spd * f, f)
            if active:
                self.cd1 -= dt
                if self.cd1 <= 0:
                    self.cd1 = 2.3 * rage
                    base = math.atan2(p.cy - cy, p.cx - cx)
                    for o in (-0.22, 0.0, 0.22):
                        g.enemy_shot(cx + self.dir * 40, cy - 10, base + o, 5.0, self.dmg * 0.55, 6)
                self.cd2 -= dt
                if self.cd2 <= 0 and self.on_ground and not self.leaping:
                    self.cd2 = 5.5 * rage
                    self.vy = -15.0
                    self.leaping = True
                    self.leap_t = 0.0
                    self.leap_dir = self.dir
        elif self.idx == 1:     # 하늘의 사신: 비행 + 방사탄
            target = WORLD_W / 2 + math.sin(self.age * 0.7 * spd) * 320 - self.w / 2
            self.x += (target - self.x) * 0.04 * f
            ty = 70 + math.sin(self.age * 1.5) * 25
            self.y += (ty - self.y) * 0.05 * f
            if active:
                self.cd1 -= dt
                if self.cd1 <= 0:
                    self.cd1 = 2.0 * rage
                    self.ang0 += 0.3
                    for k in range(10):
                        g.enemy_shot(cx, cy + 10, self.ang0 + k * math.pi / 5, 3.2, self.dmg * 0.5, 5)
                self.cd2 -= dt
                if self.cd2 <= 0:
                    self.cd2 = 3.6 * rage
                    base = math.atan2(p.cy - cy, p.cx - cx)
                    for o in (-0.16, 0.0, 0.16):
                        g.enemy_shot(cx, cy + 14, base + o, 5.2, self.dmg * 0.6, 5)
        else:                   # 오메가 코어: 천천히 추격 + 5방향 사격 + 졸개 소환
            move_entity(self, self.dir * 0.9 * spd * f, f)
            if active:
                self.cd1 -= dt
                if self.cd1 <= 0:
                    self.cd1 = 1.4 * rage
                    base = math.atan2(p.cy - cy, p.cx - cx)
                    for o in (-0.4, -0.2, 0.0, 0.2, 0.4):
                        g.enemy_shot(cx, cy, base + o, 4.4, self.dmg * 0.45, 5)
                self.cd2 -= dt
                if self.cd2 <= 0:
                    self.cd2 = 6.0 * rage
                    g.rings.append(Ring(cx, cy, 10, 70, 0.4, (160, 120, 255), 4))
                    g.spawn_specific("scrap", clamp(cx - 80, 10, WORLD_W - 50))
                    g.spawn_specific("kami", clamp(cx + 80, 10, WORLD_W - 50))

    def draw(self, surf, t):
        x, y, w, h = int(self.x), int(self.y), self.w, self.h
        cx, cy = x + w // 2, y + h // 2
        fl = self.flash > 0
        en = self.enraged
        pulse = 0.5 + 0.5 * math.sin(t * (12 if en else 6))

        def c(col):
            if fl:
                return (255, 255, 255)
            if en:
                return (min(255, col[0] + 50), max(0, col[1] - 20), max(0, col[2] - 20))
            return col

        core = lerp_color((120, 20, 20), (255, 120, 90), pulse)
        if self.grace > 0 and int(t * 14) % 2 == 0:
            pygame.draw.rect(surf, (255, 255, 255), (x, y, w, h), 2)
        if self.idx == 0:
            step = int(math.sin(self.age * 6) * 4) if self.on_ground else 0
            pygame.draw.rect(surf, c((70, 75, 90)), (x + 12, y + h - 30, 24, 30 - step))
            pygame.draw.rect(surf, c((70, 75, 90)), (x + w - 36, y + h - 30, 24, 30 + step if step < 0 else 30))
            pygame.draw.rect(surf, c((105, 110, 128)), (x + 8, y + 24, w - 16, h - 54), border_radius=6)
            pygame.draw.rect(surf, c((60, 62, 76)), (x - 6, y + 20, 24, 28), border_radius=5)
            pygame.draw.rect(surf, c((60, 62, 76)), (x + w - 18, y + 20, 24, 28), border_radius=5)
            pygame.draw.rect(surf, c((130, 135, 150)), (x + 28, y, 36, 26), border_radius=4)
            pygame.draw.rect(surf, core, (x + 34, y + 9, 24, 6))
            pygame.draw.circle(surf, core, (cx, y + 58), 10)
            pygame.draw.line(surf, c((40, 42, 52)), (cx, y + 40), (cx + self.dir * 52, y + 40), 10)
        elif self.idx == 1:
            pygame.draw.polygon(surf, c((90, 30, 45)), [(x + 28, y + 18), (x - 12, y + 2), (x + 8, y + 42)])
            pygame.draw.polygon(surf, c((90, 30, 45)), [(x + w - 28, y + 18), (x + w + 12, y + 2), (x + w - 8, y + 42)])
            pygame.draw.ellipse(surf, c((60, 25, 40)), (x + 22, y + 6, w - 44, h - 10))
            pygame.draw.circle(surf, core, (cx, cy), 10)
            for k in (-22, 0, 22):
                pygame.draw.line(surf, c((30, 20, 30)), (cx + k, y + h - 8), (cx + k, y + h + 4), 4)
        else:
            r = w // 2
            pygame.draw.circle(surf, c((60, 50, 100)), (cx, cy), r)
            pygame.draw.circle(surf, c((90, 80, 150)), (cx, cy), r - 8)
            for k in range(6):
                a = k * math.pi / 3 + self.age * 1.5
                pygame.draw.circle(surf, c((170, 150, 255)), (int(cx + math.cos(a) * (r + 6)), int(cy + math.sin(a) * (r + 6))), 6)
            pygame.draw.circle(surf, core, (cx + self.dir * 4, cy), 12)
            pygame.draw.circle(surf, (20, 10, 20), (cx + self.dir * 6, cy), 5)


# ------------------------------------------------------------
# 로봇 그리기 (수리 단계에 따라 모습이 변함)
# ------------------------------------------------------------
def draw_robot_sprite(p, t):
    S = pygame.Surface((80, 70), pygame.SRCALPHA)
    ox, oy = 23, 10
    r = p.repair
    legs_ok, gun_ok, arm_ok, head_ok, core_ok = r > 0, r > 1, r > 2, r > 3, r > 4
    gold = r >= 5
    body = (235, 205, 70) if gold else ((90, 150, 215) if core_ok else (115, 115, 125))
    steel = (175, 180, 192)
    dark = (55, 58, 70)
    rust = (130, 85, 55)
    walk = int(math.sin(t * 14) * 3) if (p.moving and p.on_ground) else 0

    def R(col, rect, **kw):
        pygame.draw.rect(S, col, (ox + rect[0], oy + rect[1], rect[2], rect[3]), **kw)

    def L(col, a, b, w=2):
        pygame.draw.line(S, col, (ox + a[0], oy + a[1]), (ox + b[0], oy + b[1]), w)

    # 다리
    if legs_ok:
        R(steel, (6 + walk, 33, 9, 15))
        R(steel, (19 - walk, 33, 9, 15))
        R(dark, (5 + walk, 45, 11, 3))
        R(dark, (18 - walk, 45, 11, 3))
    else:
        R(rust, (6, 41, 9, 7))
        R(dark, (19, 33, 9, 15))
        L((230, 200, 60), (10, 41), (7, 36), 1)
    # 몸통
    R(body, (4, 14, 26, 20), border_radius=3)
    R(dark, (4, 14, 26, 20), width=2, border_radius=3)
    if core_ok:
        pygame.draw.circle(S, (255, 255, 200) if gold else (140, 240, 255), (ox + 17, oy + 24), 5)
    else:
        L(dark, (10, 16), (16, 26), 2)
        L(dark, (16, 26), (13, 33), 2)
        R(rust, (20, 20, 6, 5))
        if int(t * 4) % 3 == 0:
            pygame.draw.circle(S, (230, 60, 50), (ox + 17, oy + 24), 3)
        else:
            pygame.draw.circle(S, (80, 40, 40), (ox + 17, oy + 24), 3)
    # 머리
    if head_ok:
        R(steel, (9, 0, 16, 14), border_radius=3)
        R((120, 235, 255), (12, 4, 10, 5))
        L(steel, (17, 0), (17, -5), 2)
        pygame.draw.circle(S, (255, 90, 90), (ox + 17, oy - 6), 2)
    else:
        R((140, 140, 150), (11, 2, 16, 13), border_radius=3)
        R((90, 60, 40), (11, 2, 6, 4))
        R((120, 235, 255) if int(t * 3) % 2 else (60, 90, 100), (14, 7, 5, 4))
        R((40, 40, 50), (21, 7, 5, 4))
        L(steel, (19, 2), (23, -2), 2)
    # 사격 팔 (앞쪽)
    if gun_ok:
        R(steel, (28, 18, 20, 8), border_radius=2)
        R(dark, (46, 19, 6, 6))
        R(body, (26, 16, 8, 12), border_radius=2)
    else:
        R(dark, (28, 19, 9, 7))
        R((90, 90, 100), (26, 16, 7, 11))
    # 뒤쪽 팔
    if arm_ok:
        R(steel, (-1, 17, 7, 17), border_radius=2)
        R(dark, (-1, 31, 7, 4))
    else:
        R(dark, (1, 18, 5, 9))
        L((235, 200, 60), (3, 27), (0, 34), 1)
    return S


def draw_robot(surf, p, t, death_t=None):
    S = draw_robot_sprite(p, t)
    if p.facing < 0:
        S = pygame.transform.flip(S, True, False)
    pos = (int(p.x) - 23, int(p.y) - 10)
    if death_t is not None:
        ang = -90 * clamp(death_t / 0.9, 0.0, 1.0) * (1 if p.facing > 0 else -1)
        img = pygame.transform.rotate(S, ang)
        rect = img.get_rect(center=(int(p.cx), int(p.y + p.h - 18 + 14 * clamp(death_t / 0.9, 0, 1))))
        surf.blit(img, rect)
        return
    if p.repair >= 5:     # 세계 제일 로봇: 황금 오라
        aura = pygame.Surface((90, 90), pygame.SRCALPHA)
        pygame.draw.circle(aura, (255, 220, 90, 55 + int(25 * math.sin(t * 5))), (45, 45), 44)
        surf.blit(aura, (int(p.cx) - 45, int(p.cy) - 45))
    surf.blit(S, pos)
    if p.shield_ready:
        pygame.draw.circle(surf, (120, 220, 255), (int(p.cx), int(p.cy)), 33, 2)


# ------------------------------------------------------------
# 게임 본체
# ------------------------------------------------------------
class Game:
    def __init__(self, diff_index):
        self.di = diff_index
        self.d = DIFFS[diff_index]
        self.p = Player(self.d)
        self.enemies, self.pb, self.eb = [], [], []
        self.sparks, self.rings, self.texts, self.delayed = [], [], [], []
        self.stage = 1
        self.stage_t = 0.0
        self.boss_count = 0
        self.spawn_t = 1.2
        self.score = 0
        self.total_t = 0.0
        self.anim = 0.0
        self.shake = 0.0
        self.banner = 0.0
        self.banner_text = ""
        self.pending_aug = 0
        self.choices = []
        self.card_rects = []
        self.state = "play"          # play / paused / augment / dying / over
        self.death_t = 0.0
        self.death_fx = 0.0
        self.saved = False
        self.rank = None

    # ---------- 편의 함수 ----------
    def nearest_enemy(self, x, y, maxd=700, need_visible=True):
        best, bd = None, maxd
        for e in self.enemies:
            if e.dead or (need_visible and e.grace > 0):
                continue
            d = math.hypot(e.x + e.w / 2 - x, e.y + e.h / 2 - y)
            if d < bd:
                best, bd = e, d
        return best

    def enemy_shot(self, x, y, ang, speed, dmg, r=5, color=(255, 90, 70)):
        self.eb.append(Bullet(x, y, math.cos(ang) * speed, math.sin(ang) * speed,
                              dmg, False, r, color, life=6.0))

    def popup(self, x, y, text, color=(255, 255, 255), big=False, life=1.0):
        if len(self.texts) < 40:
            self.texts.append(FloatText(x, y, text, color, big, life))

    # ---------- 이펙트 ----------
    def explode(self, x, y, size=1.0, color=(255, 170, 50)):
        self.rings.append(Ring(x, y, 8 * size, 38 * size, 0.35, (255, 220, 150), 3))
        self.rings.append(Ring(x, y, 4 * size, 24 * size, 0.2, (255, 255, 230), 0))
        if len(self.sparks) < 700:
            for _ in range(int(12 * size) + 6):
                a = random.uniform(0, math.tau)
                sp = random.uniform(1.5, 6.5) * (0.6 + 0.5 * size)
                col = random.choice([color, (255, 230, 100), (255, 110, 40), (200, 200, 200)])
                self.sparks.append(Spark(x, y, math.cos(a) * sp, math.sin(a) * sp,
                                         random.uniform(0.3, 0.8), col, random.randint(2, 4), 0.15))
            for _ in range(int(4 * size) + 2):
                a = random.uniform(math.pi, math.tau)
                sp = random.uniform(2, 6)
                self.sparks.append(Spark(x, y, math.cos(a) * sp, math.sin(a) * sp,
                                         random.uniform(0.6, 1.1), (90, 90, 100), random.randint(3, 6), 0.4, True))
        self.shake = min(0.7, max(self.shake, 0.08 * size))

    def hit_spark(self, x, y, color):
        for _ in range(4):
            a = random.uniform(0, math.tau)
            sp = random.uniform(1, 3.5)
            self.sparks.append(Spark(x, y, math.cos(a) * sp, math.sin(a) * sp, 0.25, color, 2, 0.1))

    def aoe(self, x, y, radius, dmg, exclude=None):
        self.rings.append(Ring(x, y, 6, radius, 0.25, (255, 170, 80), 3))
        for e in self.enemies:
            if e.dead or e is exclude:
                continue
            ddx = max(e.x - x, 0, x - (e.x + e.w))
            ddy = max(e.y - y, 0, y - (e.y + e.h))
            if math.hypot(ddx, ddy) <= radius:
                self.damage_enemy(e, dmg, False)

    # ---------- 스테이지 / 보스 ----------
    def next_stage(self):
        self.stage += 1
        self.stage_t = 0.0
        boss = Boss(self, self.boss_count)
        self.boss_count += 1
        self.enemies.append(boss)
        self.banner = 3.0
        self.banner_text = T("경고! 보스 출현", "WARNING! BOSS APPROACHING")
        self.shake = max(self.shake, 0.3)

    def boss_killed(self, b):
        p = self.p
        for i in range(12):
            self.delayed.append([i * 0.13, b.x + random.uniform(0, b.w), b.y + random.uniform(0, b.h),
                                 random.uniform(1.0, 1.8)])
        self.delayed.append([1.7, b.x + b.w / 2, b.y + b.h / 2, 3.2])
        self.eb = []
        p.hp = min(p.max_hp, p.hp + p.max_hp * 0.3)
        self.pending_aug += 1
        self.score += int(500 * self.stage * self.d["mult"])
        self.banner = 3.0
        self.banner_text = T("보스 격파! 보너스 증강", "BOSS DESTROYED! BONUS AUGMENT")

    # ---------- 적 생성 ----------
    def pick_type(self):
        pool = [("scrap", 10), ("drone", 6), ("gunner", 4), ("kami", 3 if self.stage >= 2 else 1)]
        if self.stage >= 2:
            pool.append(("tank", min(6, 1 + self.stage)))
        total = sum(w for _, w in pool)
        r = random.uniform(0, total)
        for t, w in pool:
            r -= w
            if r <= 0:
                return t
        return "scrap"

    def spawn_interval(self):
        base = 1.8 * self.d["spawn"] / (1 + 0.1 * (self.stage - 1))
        return max(0.35, base * random.uniform(0.8, 1.2))

    def spawn_specific(self, t, x):
        cfg = ETYPES[t]
        self.enemies.append(Enemy(self, t, x, GROUND_Y - cfg["h"]))

    def spawn_enemy(self):
        nonboss = [e for e in self.enemies if not e.is_boss and not e.dead]
        if len(nonboss) >= min(30, 7 + 2 * self.stage):
            return
        t = self.pick_type()
        cfg = ETYPES[t]
        p = self.p
        if cfg["kind"] == "platform":
            free = [pl for pl in FLOATING
                    if not any(getattr(e, "plat", None) is pl for e in self.enemies)]
            if free:
                pl = random.choice(free)
                x = random.randint(pl.left, pl.right - cfg["w"])
                self.enemies.append(Enemy(self, t, x, pl.top - cfg["h"], plat=pl))
                return
            t = "scrap"
            cfg = ETYPES[t]
        if cfg["kind"] == "fly":
            x = random.choice([10, WORLD_W - cfg["w"] - 10])
            self.enemies.append(Enemy(self, t, x, random.randint(40, 120)))
            return
        cands = [10, WORLD_W - cfg["w"] - 10]
        cands = [x for x in cands if abs(p.cx - x) > 220]
        if not cands:
            return
        self.enemies.append(Enemy(self, t, random.choice(cands), GROUND_Y - cfg["h"]))

    # ---------- 전투 ----------
    def damage_enemy(self, e, dmg, crit=False):
        if e.dead:
            return
        e.hp -= dmg
        e.flash = 0.08
        self.popup(e.x + e.w / 2 + random.randint(-8, 8), e.y - 4, str(int(dmg)),
                   (255, 230, 90) if crit else (255, 255, 255), crit, 0.6)
        if e.hp <= 0:
            self.kill_enemy(e)

    def kill_enemy(self, e, credit=True):
        e.dead = True
        cx, cy = e.x + e.w / 2, e.y + e.h / 2
        if e.is_boss:
            self.boss_killed(e)
        else:
            size = 1.0 + e.w / 60.0
            self.explode(cx, cy, size)
        if not credit:
            return
        p = self.p
        self.score += int(e.score * self.d["mult"] * (1 + 0.1 * (self.stage - 1)))
        p.xp += e.xp
        p.kills += 1
        if p.lifesteal > 0 and p.hp < p.max_hp:
            p.hp = min(p.max_hp, p.hp + p.lifesteal)
        while p.xp >= p.xp_need():
            p.xp -= p.xp_need()
            p.level += 1
            self.pending_aug += 1
            self.popup(p.cx, p.y - 24, T("레벨 업!", "LEVEL UP!"), (255, 255, 120), True, 1.4)
        while p.repair < 5 and p.kills >= REPAIR_AT[p.repair]:
            idx = p.repair
            p.repair += 1
            p.max_hp += 10
            p.hp = min(p.max_hp, p.hp + p.max_hp * 0.35)
            p.dmg *= 1.08
            name = REPAIR_NAMES[idx][0] if KO else REPAIR_NAMES[idx][1]
            self.popup(p.cx, p.y - 44, T("수리 완료: ", "REPAIRED: ") + name, (120, 255, 170), True, 2.0)
            self.rings.append(Ring(p.cx, p.cy, 10, 60, 0.6, (120, 255, 170), 3))
            if p.repair >= 5:
                self.banner = 3.5
                self.banner_text = T("세계 제일의 로봇 완성!", "THE WORLD'S BEST ROBOT!")

    def hurt_player(self, amount, src_x):
        p = self.p
        if p.inv > 0 or self.state != "play":
            return
        if p.shield_ready:
            p.shield_ready = False
            p.shield_cd = max(4.0, 13.0 - 2.5 * p.shield_lvl)
            p.inv = 0.6
            self.rings.append(Ring(p.cx, p.cy, 20, 50, 0.3, (120, 220, 255), 3))
            self.popup(p.cx, p.y - 10, T("방어!", "BLOCK!"), (120, 220, 255))
            return
        p.hp -= amount
        p.inv = 0.9
        p.kb = 6.0 if p.cx >= src_x else -6.0
        p.vy = -4.5
        self.shake = max(self.shake, 0.18)
        self.popup(p.cx, p.y - 8, "-" + str(int(amount)), (255, 90, 90), True, 0.8)
        for _ in range(8):
            a = random.uniform(0, math.tau)
            self.sparks.append(Spark(p.cx, p.cy, math.cos(a) * 3, math.sin(a) * 3, 0.4, (255, 200, 80), 3, 0.2))
        if p.hp <= 0:
            p.hp = 0
            self.state = "dying"      # 6. 게임 종료: HP 0 → 쓰러짐
            self.death_t = 0.0
            self.eb = []
            self.explode(p.cx, p.cy, 1.5, (255, 120, 60))

    # ---------- 업데이트 ----------
    def update(self, dt, keys):
        if self.state == "play":
            self.update_play(dt, keys)
        elif self.state == "dying":
            self.update_dying(dt)

    def update_play(self, dt, keys):
        f = dt * 60.0
        p = self.p
        self.total_t += dt
        self.anim += dt
        self.stage_t += dt
        if self.stage_t >= STAGE_TIME:
            self.next_stage()

        self.update_player(dt, f, keys)

        self.spawn_t -= dt
        if self.spawn_t <= 0:
            self.spawn_enemy()
            self.spawn_t = self.spawn_interval()

        for e in self.enemies:
            if not e.dead:
                e.update(self, dt, f)

        for b in self.pb + self.eb:
            b.update(self, dt, f)

        # 내 탄 → 적
        for b in self.pb:
            if b.dead:
                continue
            for e in self.enemies:
                if e.dead or id(e) in b.hit:
                    continue
                if e.rect().inflate(b.r * 2, b.r * 2).collidepoint(b.x, b.y):
                    self.damage_enemy(e, b.dmg, b.crit)
                    b.hit.add(id(e))
                    if b.explosive:
                        self.aoe(b.x, b.y, 30 + 14 * b.explosive, b.dmg * 0.6, exclude=e)
                    if b.pierce > 0:
                        b.pierce -= 1
                    else:
                        b.dead = True
                        self.hit_spark(b.x, b.y, b.color)
                    break

        # 적 탄 → 플레이어
        pr = p.rect().inflate(-8, -6)
        for b in self.eb:
            if b.dead:
                continue
            if pr.inflate(b.r * 2, b.r * 2).collidepoint(b.x, b.y):
                b.dead = True
                self.hurt_player(b.dmg, b.x)

        # 5. 충돌 판정: 적과 접촉해도 HP 감소
        for e in self.enemies:
            if e.dead or e.grace > 0:
                continue
            if pr.colliderect(e.rect().inflate(-4, -4)):
                self.hurt_player(e.dmg, e.x + e.w / 2)
                if e.t == "kami":
                    self.explode(e.x + e.w / 2, e.y + e.h / 2, 1.2, (255, 90, 60))
                    e.dead = True

        # 회전 톱날
        if p.saw > 0:
            p.saw_angle += 3.6 * dt
            for i in range(p.saw):
                a = p.saw_angle + i * math.tau / p.saw
                sx, sy = p.cx + math.cos(a) * 70, p.cy + math.sin(a) * 70
                for e in self.enemies:
                    if e.dead or e.saw_cd > 0 or e.grace > 0:
                        continue
                    if e.rect().inflate(24, 24).collidepoint(sx, sy):
                        e.saw_cd = 0.35
                        self.damage_enemy(e, p.dmg * 1.1, False)

        self.pb = [b for b in self.pb if not b.dead]
        self.eb = [b for b in self.eb if not b.dead]
        self.enemies = [e for e in self.enemies if not e.dead]
        self.update_fx(dt, f)

        if self.pending_aug > 0 and self.state == "play":
            self.open_augment()

    def update_player(self, dt, f, keys):
        p = self.p
        dirx = (1 if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) else 0) - \
               (1 if (keys[pygame.K_LEFT] or keys[pygame.K_a]) else 0)
        p.moving = dirx != 0
        mv = dirx * p.speed * f + p.kb * f
        p.kb *= 0.86 ** f
        move_entity(p, mv, f)
        if p.on_ground:
            p.air_left = p.extra_jumps
        p.inv = max(0.0, p.inv - dt)
        p.fire_cd -= dt

        if p.regen > 0 and p.hp < p.max_hp:
            p.hp = min(p.max_hp, p.hp + p.regen * dt)
        if p.shield_lvl > 0 and not p.shield_ready:
            p.shield_cd -= dt
            if p.shield_cd <= 0:
                p.shield_ready = True
                self.popup(p.cx, p.y - 10, T("실드 충전", "SHIELD READY"), (120, 220, 255))

        # 자동 조준 + 자동 발사
        target = self.nearest_enemy(p.cx, p.cy, 760)
        if target:
            tx, ty = target.x + target.w / 2, target.y + target.h / 2
            p.facing = 1 if tx > p.cx else -1
            if p.fire_cd <= 0:
                p.fire_cd = p.fire_delay
                gx, gy = p.cx + p.facing * 20, p.y + 22
                base = math.atan2(ty - gy, tx - gx)
                n = p.bullets
                for i in range(n):
                    a = base + (i - (n - 1) / 2) * 0.13
                    crit = random.random() < p.crit
                    self.pb.append(Bullet(gx, gy, math.cos(a) * 13, math.sin(a) * 13,
                                          p.dmg * (2.0 if crit else 1.0), True, 4,
                                          (255, 230, 90) if crit else (120, 230, 255),
                                          pierce=p.pierce, explosive=p.explosive, crit=crit))
                self.sparks.append(Spark(gx, gy, p.facing * 2, 0, 0.1, (200, 255, 255), 4, 0))
        elif p.moving:
            p.facing = dirx

        # 유도 미사일
        if p.missile > 0:
            p.missile_cd -= dt
            if p.missile_cd <= 0:
                tg = self.nearest_enemy(p.cx, p.cy, 9999)
                if tg:
                    p.missile_cd = max(0.8, 2.8 - 0.4 * p.missile)
                    a = -math.pi / 2 + random.uniform(-0.5, 0.5)
                    self.pb.append(Bullet(p.cx, p.y, math.cos(a) * 6, math.sin(a) * 6,
                                          p.dmg * 1.8 + 10, True, 5, (255, 140, 80),
                                          explosive=1, homing=True, life=3.5))

    def do_jump(self):
        p = self.p
        if self.state != "play":
            return
        if p.on_ground:
            p.vy = -JUMP_V
            p.on_ground = False
        elif p.air_left > 0:
            p.air_left -= 1
            p.vy = -JUMP_V * 0.95
            self.rings.append(Ring(p.cx, p.y + p.h, 4, 24, 0.25, (200, 220, 255), 2))

    def update_fx(self, dt, f):
        for s in self.sparks:
            s.update(f, dt)
        for r in self.rings:
            r.update(f, dt)
        for tx in self.texts:
            tx.update(f, dt)
        self.sparks = [s for s in self.sparks if s.life > 0]
        self.rings = [r for r in self.rings if r.life > 0]
        self.texts = [t for t in self.texts if t.life > 0]
        for d in self.delayed:
            d[0] -= dt
            if d[0] <= 0:
                self.explode(d[1], d[2], d[3], (255, 150, 60))
        self.delayed = [d for d in self.delayed if d[0] > 0]
        self.shake = max(0.0, self.shake - dt)
        self.banner = max(0.0, self.banner - dt)
        p = self.p
        if p.repair < 5 and self.state == "play":
            if random.random() < (0.04 + (5 - p.repair) * 0.02) * f:
                self.sparks.append(Spark(p.x + random.randint(2, p.w - 2), p.y + random.randint(8, 40),
                                         random.uniform(-1, 1), random.uniform(-2, -0.5), 0.35,
                                         (255, 220, 80), 2, 0.15))

    def update_dying(self, dt):
        f = dt * 60.0
        self.anim += dt
        self.death_t += dt
        self.death_fx -= dt
        if self.death_fx <= 0 and self.death_t < 1.8:
            self.death_fx = 0.15
            p = self.p
            self.explode(p.cx + random.randint(-14, 14), p.cy + random.randint(-20, 20), 0.7, (255, 140, 60))
        self.update_fx(dt, f)
        if self.death_t >= 2.2:
            self.state = "over"

    # ---------- 증강 ----------
    def open_augment(self):
        p = self.p
        cand = [a for a in AUGS if p.aug.get(a["key"], 0) < a["max"]]
        non_heal = [a for a in cand if a["key"] != "heal"]
        random.shuffle(non_heal)
        self.choices = non_heal[:3]
        if len(self.choices) < 3:
            heal = [a for a in AUGS if a["key"] == "heal"]
            self.choices += heal
        self.state = "augment"

    def pick_augment(self, i):
        if self.state != "augment" or i < 0 or i >= len(self.choices):
            return
        a = self.choices[i]
        a["fn"](self.p)
        self.p.aug[a["key"]] = self.p.aug.get(a["key"], 0) + 1
        self.popup(self.p.cx, self.p.y - 20, aug_name(a), a["color"], True, 1.4)
        self.pending_aug -= 1
        if self.pending_aug > 0:
            self.open_augment()
        else:
            self.state = "play"

    # ---------- 그리기 ----------
    def draw_world(self, surf):
        t = self.anim
        surf.blit(BG, (0, 0))
        # 바닥
        pygame.draw.rect(surf, (36, 32, 36), GROUND)
        pygame.draw.line(surf, (95, 82, 72), (0, GROUND_Y), (WORLD_W, GROUND_Y), 3)
        for i in range(0, WORLD_W, 60):
            pygame.draw.line(surf, (24, 22, 26), (i, GROUND_Y + 4), (i + 18, GROUND_Y + 22), 2)
        # 발판
        for pl in FLOATING:
            pygame.draw.rect(surf, (110, 72, 48), pl, border_radius=3)
            pygame.draw.rect(surf, (160, 110, 70), (pl.left, pl.top, pl.width, 4))
            for rx in range(pl.left + 8, pl.right - 4, 24):
                pygame.draw.circle(surf, (70, 45, 30), (rx, pl.top + 8), 2)

        for e in self.enemies:
            e.draw(surf, t)
        for b in self.pb:
            b.draw(surf)
        for b in self.eb:
            b.draw(surf)

        p = self.p
        if self.state in ("dying", "over"):
            draw_robot(surf, p, t, self.death_t)
        else:
            if not (p.inv > 0 and int(t * 20) % 2 == 0):
                draw_robot(surf, p, t)
        # 톱날
        if p.saw > 0 and self.state not in ("dying", "over"):
            for i in range(p.saw):
                a = p.saw_angle + i * math.tau / p.saw
                sx, sy = int(p.cx + math.cos(a) * 70), int(p.cy + math.sin(a) * 70)
                pygame.draw.circle(surf, (210, 210, 225), (sx, sy), 12)
                for k in range(6):
                    aa = a * 4 + k * math.pi / 3
                    pygame.draw.line(surf, (90, 90, 105), (sx, sy), (sx + math.cos(aa) * 12, sy + math.sin(aa) * 12), 2)
                pygame.draw.circle(surf, (60, 60, 75), (sx, sy), 4)

        for r in self.rings:
            r.draw(surf)
        for s in self.sparks:
            s.draw(surf)
        for tx in self.texts:
            tx.draw(surf)
        self.draw_hud(surf)

    def draw_hud(self, surf):
        p = self.p
        # HP
        pygame.draw.rect(surf, (20, 20, 25), (10, 8, 244, 22), border_radius=4)
        k = clamp(p.hp / p.max_hp, 0, 1)
        col = lerp_color((230, 60, 60), (90, 230, 120), k)
        pygame.draw.rect(surf, col, (12, 10, int(240 * k), 18), border_radius=3)
        draw_text(surf, "HP %d / %d" % (math.ceil(p.hp), int(p.max_hp)), F_S, (255, 255, 255), (132, 19), "center")
        # XP
        pygame.draw.rect(surf, (20, 20, 25), (10, 34, 244, 12), border_radius=3)
        pygame.draw.rect(surf, (110, 160, 255), (12, 36, int(240 * clamp(p.xp / p.xp_need(), 0, 1)), 8), border_radius=2)
        draw_text(surf, "LV %d" % p.level, F_S, (200, 220, 255), (262, 34))
        # 수리 상태
        draw_text(surf, T("수리 ", "REPAIR ") + "%d/5" % p.repair, F_S, (170, 255, 200), (12, 52))
        for i in range(5):
            ok = p.repair > i
            rc = pygame.Rect(92 + i * 18, 52, 14, 14)
            pygame.draw.rect(surf, (90, 230, 140) if ok else (70, 70, 80), rc, border_radius=2)
            if not ok:
                pygame.draw.line(surf, (200, 70, 70), rc.topleft, rc.bottomright, 2)
                pygame.draw.line(surf, (200, 70, 70), rc.topright, rc.bottomleft, 2)

        # 보스 체력바
        boss = next((e for e in self.enemies if e.is_boss and not e.dead), None)
        if boss:
            bw = 330
            bx = 300
            pygame.draw.rect(surf, (20, 10, 14), (bx - 2, 10, bw + 4, 18), border_radius=4)
            pygame.draw.rect(surf, (230, 50, 70) if not boss.enraged else (255, 130, 40),
                             (bx, 12, int(bw * clamp(boss.hp / boss.max_hp, 0, 1)), 14), border_radius=3)
            draw_text(surf, boss.name, F_S, (255, 255, 255), (bx + bw // 2, 19), "center")

        # 스테이지 / 점수
        remain = max(0, STAGE_TIME - self.stage_t)
        draw_text(surf, "STAGE %d" % self.stage, F_L, (255, 230, 150), (WORLD_W - 12, 6), "topright")
        draw_text(surf, T("다음 보스 ", "NEXT BOSS ") + "%02d:%02d" % (int(remain) // 60, int(remain) % 60),
                  F_S, (255, 160, 140), (WORLD_W - 12, 44), "topright")
        draw_text(surf, T("점수 ", "SCORE ") + "%d" % self.score, F_M, (255, 255, 255), (WORLD_W - 12, 62), "topright")
        draw_text(surf, T("처치 ", "KILLS ") + "%d" % p.kills, F_S, (200, 200, 210), (WORLD_W - 12, 86), "topright")

        # 보유 증강 (바닥 영역에 표시)
        x, y = 10, GROUND_Y + 8
        for a in AUGS:
            n = p.aug.get(a["key"], 0)
            if n <= 0:
                continue
            txt = "%s x%d" % (aug_name(a), n)
            img = F_S.render(txt, True, a["color"])
            if x + img.get_width() > WORLD_W - 10:
                x = 10
                y += 18
            surf.blit(img, (x, y))
            x += img.get_width() + 14
        if not p.aug:
            draw_text(surf, T("레벨 업 / 보스 처치로 증강을 얻으세요", "Level up or defeat bosses to gain augments"),
                      F_S, (140, 140, 150), (10, GROUND_Y + 8))

        # 배너
        if self.banner > 0:
            if int(self.banner * 6) % 2 == 0 or self.banner < 1:
                draw_text(surf, self.banner_text, F_L, (255, 90, 90), (WORLD_W // 2, 130), "center")

    def draw_overlay(self, surf):
        cxw = PANEL_W + WORLD_W // 2
        if self.state == "augment":
            veil = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
            veil.fill((0, 0, 0, 170))
            surf.blit(veil, (PANEL_W, 0))
            draw_text(surf, T("증강을 선택하세요  (1 / 2 / 3)", "Choose an augment  (1 / 2 / 3)"),
                      F_L, (255, 240, 150), (cxw, 90), "center")
            self.card_rects = []
            mx, my = pygame.mouse.get_pos()
            cw, ch, gap = 240, 250, 20
            total = len(self.choices) * cw + (len(self.choices) - 1) * gap
            x0 = cxw - total // 2
            for i, a in enumerate(self.choices):
                rc = pygame.Rect(x0 + i * (cw + gap), 150, cw, ch)
                self.card_rects.append(rc)
                hov = rc.collidepoint(mx, my)
                pygame.draw.rect(surf, (40, 44, 58) if not hov else (62, 68, 90), rc, border_radius=10)
                pygame.draw.rect(surf, a["color"], rc, 3, border_radius=10)
                draw_text(surf, str(i + 1), F_XL, a["color"], (rc.centerx, rc.y + 50), "center")
                draw_text(surf, aug_name(a), F_M, (255, 255, 255), (rc.centerx, rc.y + 110), "center")
                draw_text(surf, aug_desc(a), F_S, (210, 210, 220), (rc.centerx, rc.y + 150), "center")
                n = self.p.aug.get(a["key"], 0)
                if a["max"] < 99:
                    draw_text(surf, "Lv %d / %d" % (n, a["max"]), F_S, (150, 150, 165), (rc.centerx, rc.y + 210), "center")
        elif self.state == "paused":
            veil = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
            veil.fill((0, 0, 0, 150))
            surf.blit(veil, (PANEL_W, 0))
            draw_text(surf, T("일시정지", "PAUSED"), F_XL, (255, 255, 255), (cxw, 220), "center")
            draw_text(surf, T("P / ESC : 계속     M : 메뉴로", "P / ESC : Resume     M : Menu"),
                      F_M, (210, 210, 220), (cxw, 290), "center")
        elif self.state == "over":
            veil = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
            veil.fill((0, 0, 0, 185))
            surf.blit(veil, (PANEL_W, 0))
            draw_text(surf, T("시스템 정지", "SYSTEM DOWN"), F_XL, (255, 80, 80), (cxw, 110), "center")
            lines = [
                (T("점수 ", "Score ") + str(int(self.score)), (255, 255, 255)),
                (T("도달 스테이지 ", "Stage reached ") + str(self.stage), (255, 230, 150)),
                (T("처치한 적 ", "Enemies destroyed ") + str(self.p.kills), (200, 200, 210)),
                (T("수리된 부위 ", "Parts repaired ") + "%d/5" % self.p.repair, (170, 255, 200)),
                (T("난이도 ", "Difficulty ") + dname(self.d), self.d["color"]),
            ]
            for i, (txt, col) in enumerate(lines):
                draw_text(surf, txt, F_M, col, (cxw, 185 + i * 34), "center")
            if self.rank:
                draw_text(surf, T("리더보드 %d위!" % self.rank, "Leaderboard rank #%d!" % self.rank),
                          F_M, (255, 220, 90), (cxw, 365), "center")
            draw_text(surf, T("R : 다시 도전     M : 메뉴", "R : Retry     M : Menu"),
                      F_M, (210, 210, 220), (cxw, 430), "center")


# ------------------------------------------------------------
# 왼쪽 리더보드 패널
# ------------------------------------------------------------
def draw_panel(surf, records, game=None):
    pygame.draw.rect(surf, (18, 20, 28), (0, 0, PANEL_W, WIN_H))
    pygame.draw.line(surf, (70, 75, 95), (PANEL_W - 1, 0), (PANEL_W - 1, WIN_H), 2)
    draw_text(surf, T("리더보드", "LEADERBOARD"), F_M, (255, 220, 120), (PANEL_W // 2, 22), "center")
    draw_text(surf, T("최고 기록 TOP 8", "BEST RECORDS TOP 8"), F_S, (140, 145, 165), (PANEL_W // 2, 44), "center")
    y = 66
    for i in range(8):
        if i < len(records):
            r = records[i]
            d = diff_by_key(r.get("diff", "veteran"))
            col = (255, 215, 90) if i == 0 else (225, 225, 235)
            draw_text(surf, "%d." % (i + 1), F_S, col, (10, y))
            draw_text(surf, "%d" % r["score"], F_M, col, (36, y - 3))
            draw_text(surf, "S%d  %s" % (r.get("stage", 1), dshort(d)), F_S, d["color"], (36, y + 17))
        else:
            draw_text(surf, "%d.  -" % (i + 1), F_S, (80, 82, 95), (10, y + 4))
        y += 42
    if game is not None:
        rank = 1 + sum(1 for r in records if r["score"] > game.score)
        pygame.draw.rect(surf, (36, 40, 56), (6, y + 2, PANEL_W - 14, 50), border_radius=6)
        draw_text(surf, T("현재 기록", "NOW"), F_S, (140, 200, 255), (14, y + 6))
        draw_text(surf, "%d" % game.score, F_M, (255, 255, 255), (14, y + 24))
        draw_text(surf, "#%d" % rank, F_M, (255, 220, 90), (PANEL_W - 14, y + 24), "topright")


# ------------------------------------------------------------
# 메뉴
# ------------------------------------------------------------
def draw_menu(surf, sel, records, t):
    surf.blit(BG, (PANEL_W, 0))
    veil = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
    veil.fill((0, 0, 0, 140))
    surf.blit(veil, (PANEL_W, 0))
    cx = PANEL_W + WORLD_W // 2
    draw_text(surf, T("폐허의 도시 : 리빌드", "RUINED CITY : REBUILD"), F_XL, (255, 210, 120), (cx, 70), "center")
    draw_text(surf, T("망가진 로봇이 적을 쓰러뜨리며 수리되어 세계 제일의 로봇이 된다!",
                      "A broken robot repairs itself with every kill and becomes the world's best!"),
              F_S, (225, 225, 235), (cx, 112), "center")
    draw_text(surf, T("난이도를 선택하세요  (↑ ↓ / 1~4, Enter 시작)", "Select difficulty  (UP/DOWN or 1-4, Enter to start)"),
              F_M, (255, 255, 255), (cx, 165), "center")
    best = {}
    for r in records:
        best[r.get("diff")] = max(best.get(r.get("diff"), 0), r["score"])
    for i, d in enumerate(DIFFS):
        y = 205 + i * 56
        rc = pygame.Rect(cx - 230, y, 460, 48)
        on = i == sel
        pygame.draw.rect(surf, (46, 50, 66) if on else (26, 28, 38), rc, border_radius=8)
        pygame.draw.rect(surf, d["color"] if on else (70, 72, 88), rc, 3 if on else 1, border_radius=8)
        draw_text(surf, ("> " if on else "") + dname(d), F_M, d["color"], (rc.x + 16, rc.y + 5))
        info = T("적 체력 x%.2g · 적 공격 x%.2g · 점수 x%.2g", "Enemy HP x%.2g · Enemy dmg x%.2g · Score x%.2g") % (d["hp"], d["dmg"], d["mult"])
        draw_text(surf, info, F_S, (190, 190, 205), (rc.x + 16, rc.y + 28))
        draw_text(surf, T("최고 ", "BEST ") + str(best.get(d["key"], 0)), F_S, (255, 220, 120), (rc.right - 12, rc.y + 8), "topright")
    draw_text(surf, T("← → 이동   Space/↑ 점프   사격은 자동 조준·자동 발사   P 일시정지",
                      "Arrows/AD move   Space/Up jump   Auto-aim & auto-fire   P pause"),
              F_S, (200, 200, 215), (cx, 450), "center")
    draw_text(surf, T("2분마다 보스 출현 · 스테이지 상승 · 레벨 업마다 증강 선택", "Boss every 2 min · Stage up · Pick an augment each level-up"),
              F_S, (200, 200, 215), (cx, 474), "center")
    draw_text(surf, T("끝없이 이어지는 무한 모드", "Endless mode"), F_S, (255, 160, 140), (cx, 498), "center")


# ------------------------------------------------------------
# 메인 루프
# ------------------------------------------------------------
def main():
    records = load_records()
    mode = "menu"
    sel = 1
    game = None
    world = pygame.Surface((WORLD_W, WORLD_H))

    def leave_game():
        if game and not game.saved and game.score > 0:
            add_record(records, game)

    while True:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                leave_game()
                pygame.quit()
                sys.exit()

            if mode == "menu":
                if ev.type == pygame.KEYDOWN:
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        sel = (sel - 1) % len(DIFFS)
                    elif ev.key in (pygame.K_DOWN, pygame.K_s):
                        sel = (sel + 1) % len(DIFFS)
                    elif pygame.K_1 <= ev.key <= pygame.K_4:
                        sel = ev.key - pygame.K_1
                    elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        game = Game(sel)
                        mode = "game"
                continue

            # ----- 게임 중 -----
            if ev.type == pygame.KEYDOWN:
                if game.state == "play":
                    if ev.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
                        game.do_jump()
                    elif ev.key in (pygame.K_p, pygame.K_ESCAPE):
                        game.state = "paused"
                elif game.state == "paused":
                    if ev.key in (pygame.K_p, pygame.K_ESCAPE):
                        game.state = "play"
                    elif ev.key == pygame.K_m:
                        leave_game()
                        mode = "menu"
                elif game.state == "augment":
                    if ev.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        game.pick_augment(ev.key - pygame.K_1)
                elif game.state == "over":
                    if ev.key == pygame.K_r:
                        game = Game(game.di)
                    elif ev.key in (pygame.K_m, pygame.K_RETURN):
                        mode = "menu"
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                if game.state == "augment":
                    for i, rc in enumerate(game.card_rects):
                        if rc.collidepoint(ev.pos):
                            game.pick_augment(i)
                            break

        if mode == "menu":
            screen.fill((0, 0, 0))
            draw_panel(screen, records)
            draw_menu(screen, sel, records, 0)
            pygame.display.flip()
            continue

        keys = pygame.key.get_pressed()
        game.update(dt, keys)
        if game.state == "over" and not game.saved:
            game.rank = add_record(records, game)

        game.draw_world(world)
        screen.fill((0, 0, 0))
        ox = oy = 0
        if game.shake > 0:
            s = int(min(game.shake, 0.6) * 18)
            ox, oy = random.randint(-s, s), random.randint(-s, s)
        screen.blit(world, (PANEL_W + ox, oy))
        draw_panel(screen, records, game)
        game.draw_overlay(screen)
        pygame.display.flip()


if __name__ == "__main__":
    main()
