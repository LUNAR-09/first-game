import pygame
import random
import sys

# ---------------- 기본 설정 ----------------
COLS, ROWS = 10, 20          # 보드 크기 (가로 10칸, 세로 20칸)
CELL = 30                    # 한 칸의 픽셀 크기
SIDE = 180                   # 오른쪽 정보 패널 너비
WIDTH = COLS * CELL + SIDE
HEIGHT = ROWS * CELL

GRAY = (128, 128, 128)       # 격자 안쪽 색 (회색)
BLACK = (0, 0, 0)            # 격자선 색 (검은색)
WHITE = (255, 255, 255)
PANEL = (30, 30, 30)

# 테트로미노 모양과 색상
SHAPES = {
    'I': ([[1, 1, 1, 1]], (0, 240, 240)),
    'O': ([[1, 1],
           [1, 1]], (240, 240, 0)),
    'T': ([[0, 1, 0],
           [1, 1, 1]], (160, 0, 240)),
    'S': ([[0, 1, 1],
           [1, 1, 0]], (0, 240, 0)),
    'Z': ([[1, 1, 0],
           [0, 1, 1]], (240, 0, 0)),
    'J': ([[1, 0, 0],
           [1, 1, 1]], (0, 0, 240)),
    'L': ([[0, 0, 1],
           [1, 1, 1]], (240, 160, 0)),
}


class Piece:
    """떨어지는 블록 하나"""

    def __init__(self, kind):
        shape, color = SHAPES[kind]
        self.shape = [row[:] for row in shape]
        self.color = color
        self.x = COLS // 2 - len(self.shape[0]) // 2
        self.y = 0

    def rotated(self):
        """시계 방향으로 90도 회전한 모양을 반환"""
        return [list(row) for row in zip(*self.shape[::-1])]


def new_piece():
    return Piece(random.choice(list(SHAPES.keys())))   # ① 무작위 생성


def valid(board, shape, x, y):
    """⑤ 충돌 판정: 벽, 바닥, 쌓인 블록과 겹치는지 검사"""
    for r, row in enumerate(shape):
        for c, v in enumerate(row):
            if not v:
                continue
            nx, ny = x + c, y + r
            if nx < 0 or nx >= COLS or ny >= ROWS:
                return False
            if ny >= 0 and board[ny][nx] is not None:
                return False
    return True


def lock_piece(board, p):
    """블록을 보드에 고정"""
    for r, row in enumerate(p.shape):
        for c, v in enumerate(row):
            if v:
                board[p.y + r][p.x + c] = p.color


def clear_lines(board):
    """③ 가득 찬 줄 제거, 제거한 줄 수 반환"""
    remain = [row for row in board if any(cell is None for cell in row)]
    cleared = ROWS - len(remain)
    for _ in range(cleared):
        remain.insert(0, [None] * COLS)
    board[:] = remain
    return cleared


def draw_board(screen, board, piece):
    # 격자 안쪽 회색 + 검은 격자선
    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c * CELL, r * CELL, CELL, CELL)
            color = board[r][c] if board[r][c] is not None else GRAY
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, BLACK, rect, 1)

    # 현재 떨어지는 블록
    if piece:
        for r, row in enumerate(piece.shape):
            for c, v in enumerate(row):
                if v and piece.y + r >= 0:
                    rect = pygame.Rect((piece.x + c) * CELL,
                                       (piece.y + r) * CELL, CELL, CELL)
                    pygame.draw.rect(screen, piece.color, rect)
                    pygame.draw.rect(screen, BLACK, rect, 1)


def draw_panel(screen, font, big_font, nxt, score, lines, game_over):
    x0 = COLS * CELL
    pygame.draw.rect(screen, PANEL, (x0, 0, SIDE, HEIGHT))
    screen.blit(font.render("NEXT", True, WHITE), (x0 + 20, 20))

    # 다음 블록 미리보기
    for r, row in enumerate(nxt.shape):
        for c, v in enumerate(row):
            if v:
                rect = pygame.Rect(x0 + 20 + c * 24, 55 + r * 24, 24, 24)
                pygame.draw.rect(screen, nxt.color, rect)
                pygame.draw.rect(screen, BLACK, rect, 1)

    screen.blit(font.render("SCORE", True, WHITE), (x0 + 20, 200))
    screen.blit(font.render(str(score), True, WHITE), (x0 + 20, 225))
    screen.blit(font.render("LINES", True, WHITE), (x0 + 20, 270))
    screen.blit(font.render(str(lines), True, WHITE), (x0 + 20, 295))

    help_lines = ["Left/Right: Move", "Up: Rotate", "Down: Soft drop",
                  "Space: Hard drop", "R: Restart"]
    for i, t in enumerate(help_lines):
        screen.blit(pygame.font.SysFont(None, 20).render(t, True, (200, 200, 200)),
                    (x0 + 10, 380 + i * 22))

    if game_over:
        # ⑥ 게임 종료 표시
        overlay = pygame.Surface((COLS * CELL, 120), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200))
        screen.blit(overlay, (0, HEIGHT // 2 - 60))
        t1 = big_font.render("GAME OVER", True, (255, 60, 60))
        t2 = font.render("Press R to restart", True, WHITE)
        screen.blit(t1, (COLS * CELL // 2 - t1.get_width() // 2, HEIGHT // 2 - 40))
        screen.blit(t2, (COLS * CELL // 2 - t2.get_width() // 2, HEIGHT // 2 + 10))


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tetris")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 30)
    big_font = pygame.font.SysFont(None, 52)

    def reset():
        return [[None] * COLS for _ in range(ROWS)], new_piece(), new_piece(), 0, 0

    board, piece, nxt, score, lines = reset()
    game_over = False

    fall_timer = 0                 # ④ 중력용 타이머
    held = {}                      # 키를 계속 누르고 있을 때 반복 이동용
    REPEAT_FIRST, REPEAT_NEXT = 200, 60

    def drop_one():
        """한 칸 내리기. 더 못 내려가면 즉시 고정하고 새 블록 생성"""
        nonlocal piece, nxt, score, lines, game_over
        if valid(board, piece.shape, piece.x, piece.y + 1):
            piece.y += 1
            return
        lock_piece(board, piece)                    # ⑤ 닿으면 즉시 고정
        cleared = clear_lines(board)
        if cleared:
            lines += cleared
            score += [0, 100, 300, 500, 800][cleared]
        piece, nxt = nxt, new_piece()
        if not valid(board, piece.shape, piece.x, piece.y):   # ⑥ 쌓여서 못 나오면 종료
            game_over = True

    def move(dx):
        if valid(board, piece.shape, piece.x + dx, piece.y):
            piece.x += dx

    def rotate():
        new_shape = piece.rotated()
        # 벽 근처에서 회전이 막히면 좌우로 살짝 밀어서 시도
        for dx in (0, -1, 1, -2, 2):
            if valid(board, new_shape, piece.x + dx, piece.y):
                piece.shape = new_shape
                piece.x += dx
                return

    def hard_drop():
        nonlocal score
        while valid(board, piece.shape, piece.x, piece.y + 1):
            piece.y += 1
            score += 2
        drop_one()

    def do_action(key):
        if key == pygame.K_LEFT:
            move(-1)
        elif key == pygame.K_RIGHT:
            move(1)
        elif key == pygame.K_DOWN:
            drop_one()

    while True:
        dt = clock.tick(60)
        now = pygame.time.get_ticks()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    board, piece, nxt, score, lines = reset()
                    game_over = False
                    fall_timer = 0
                    held.clear()
                    continue
                if game_over:
                    continue
                if event.key == pygame.K_UP:        # ② 회전
                    rotate()
                elif event.key == pygame.K_SPACE:
                    hard_drop()
                elif event.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_DOWN):
                    do_action(event.key)
                    held[event.key] = now + REPEAT_FIRST
            if event.type == pygame.KEYUP:
                held.pop(event.key, None)

        if not game_over:
            # 키를 누르고 있는 동안 반복 이동
            for key in list(held.keys()):
                if now >= held[key]:
                    do_action(key)
                    held[key] = now + REPEAT_NEXT
                    if game_over:
                        break

            # ④ 일정 시간 간격으로 자동 하강 (줄을 지울수록 빨라짐)
            interval = max(100, 800 - (lines // 5) * 60)
            fall_timer += dt
            if fall_timer >= interval:
                fall_timer = 0
                drop_one()

        screen.fill(BLACK)
        draw_board(screen, board, None if game_over and False else piece)
        draw_panel(screen, font, big_font, nxt, score, lines, game_over)
        pygame.display.flip()


if __name__ == "__main__":
    main()
