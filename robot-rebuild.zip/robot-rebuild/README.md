# 폐허의 도시 : 리빌드 3D (Ruined City : Rebuild 3D)

망가진 로봇이 폐허가 된 도시에서 적을 처치할수록 몸이 수리되어, 마침내 **세계 제일의 로봇**이 되는 3D 로그라이크 액션 게임입니다.
별도의 3D 엔진 없이 **pygame만으로 직접 만든 소프트웨어 3D 렌더러**(원근 투영, 면 정렬, 안개, 조명)를 사용합니다.

> A 3D roguelike action game built with pygame only. A broken robot repairs itself with every kill and becomes the world's best.
> The 3D view is a hand-written software renderer (perspective projection, painter's sort, fog, lighting) — no OpenGL needed.

## 실행 방법 (Run)

```bash
pip install -r requirements.txt
python roguelike_robot_3d.py
```

- Python 3.9 이상 권장
- Python 3.13 / 3.14 에서는 `pygame` 대신 **`pygame-ce`** 를 설치하세요 (코드의 `import pygame` 은 그대로 동작합니다).
- Thonny 에서는 **도구 → 패키지 관리** 에서 `pygame-ce` 를 설치한 뒤 파일을 열고 F5

## 조작 (Controls)

| 키 | 동작 |
|---|---|
| W A S D | 이동 (카메라 기준) |
| Space / ↑ | 점프 (증강으로 공중 점프 가능) |
| Q E / ← → | 카메라 회전 |
| (자동) | 가장 가까운 적을 향해 자동 조준 + 자동 발사 |
| P / ESC | 일시정지 |
| 1 2 3 / 마우스 클릭 | 증강 선택 |
| ↑ ↓ / 1~4, Enter | 메뉴에서 난이도 선택 / 시작 |

## 게임 특징 (Features)

- **적 5종 + 보스 3종**: 고철병, 자폭로봇, 드론, 건너, 탱크 / 강철 골리앗, 하늘의 사신, 오메가 코어
- **2분마다 보스 출현 + 스테이지 상승**, 무한 모드
- **폭발 연출**과 함께 사라지는 적, 적과 **접촉해도 HP 감소** (점프로 피할 수 있음)
- **수리 시스템**: 처치 수에 따라 다리 → 사격팔 → 왼팔 → 머리 → 코어 순으로 로봇이 수리되고, 모습도 바뀝니다. 모두 고치면 황금 로봇!
- **로그라이크 증강 15종** (각각 아이콘 포함): 최대 HP, 공격력, 연사, 이동 속도, 공중 점프, 다중 발사, 관통탄, 폭발탄, 나노 수리, 자가 수복, 에너지 실드, 유도 미사일, 회전 톱날, 치명 코어, 긴급 수리 키트
- **난이도 4단계**: 초보 / 베테랑 / 인세인 / 나이트메어
- **왼쪽 리더보드**에 최고 기록 TOP 8 (`robot3d_records.json` 에 저장)
- 한글 폰트가 있으면 한글, 없으면 영어로 자동 표시

## 폴더 구조 (Structure)

```
roguelike_robot_3d.py     # 메인 게임 (3D)
requirements.txt
extras/
  roguelike_robot_2d.py   # 이전 2D 버전
  tetris.py               # 테트리스
```

## 라이선스 (License)

MIT License — 자유롭게 수정/배포할 수 있습니다. 이름이나 연도를 바꾸려면 `LICENSE` 파일을 수정하세요.
